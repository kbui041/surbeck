import { useState } from "react";
import { NavLink, Link, useLocation } from "react-router-dom";

const links = [
  {
    to: "/why-surbeck",
    label: "Why Surbeck",
    children: [
      { to: "/why-surbeck", label: "Why Surbeck Orthodontics" },
      { to: "/finding-the-right-orthodontist", label: "Finding the Right Orthodontist" },
      { to: "/why-faster", label: "Why Treatment Can Be Faster" },
    ],
  },
  {
    to: "/treatment-process",
    label: "Treatment",
    children: [
      { to: "/treatment-process", label: "Our Treatment Process" },
      { to: "/treatment-process#before-treatment", label: "Before Treatment" },
      { to: "/treatment-process#getting-braces-placed", label: "Getting Braces Placed" },
      { to: "/treatment-process#adjustment-appointments", label: "Adjustment Appointments" },
      { to: "/treatment-process#debonding", label: "Getting Braces Removed & Retainers" },
      { to: "/braces-vs-invisalign", label: "Braces vs. Invisalign" },
      { to: "/complex-cases", label: "Complex Cases" },
    ],
  },
  { to: "/gallery", label: "Results" },
  {
    to: "/about",
    label: "About",
    children: [
      { to: "/about", label: "Meet Dr. Surbeck" },
      { to: "/team", label: "Meet Our Team" },
    ],
  },
  {
    to: "/resources",
    label: "Resources",
    children: [
      { to: "/patient-education", label: "Patient Education Library" },
      { to: "/resources/videos", label: "Treatment Videos" },
      { to: "/resources/new-patient-forms", label: "New Patient Forms" },
      { to: "/resources/retainers", label: "Retainers & Retention" },
      { to: "/resources/emergencies", label: "Broken Brackets & Emergencies" },
      { to: "/resources/adult-orthodontics", label: "Adult Orthodontics" },
      { to: "/resources/faq", label: "Frequently Asked Questions" },
      { to: "/financial", label: "Financial Information" },
    ],
  },
  {
    to: "/referrals",
    label: "Referrals",
    children: [
      { to: "/referrals", label: "Patient Referrals" },
      { to: "/referring-dentists", label: "Referring Dentists" },
    ],
  },
];

export default function Header() {
  const [open, setOpen] = useState(false);
  const [openSub, setOpenSub] = useState(null);
  const location = useLocation();

  const closeAll = () => {
    setOpen(false);
    setOpenSub(null);
  };

  return (
    <header className="header">
      <div className="wrap">
        <Link to="/" className="brand" onClick={() => setOpen(false)} aria-label="Surbeck Orthodontics">
          <span className="b">SURBECK</span>
          <span className="o">Orthodontics</span>
        </Link>

        <button
          className="nav-toggle"
          aria-label="Toggle menu"
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
        >
          <span />
        </button>

        <nav className={`nav ${open ? "open" : ""}`}>
          {links.map((l) => {
            const isGroupActive =
              l.children &&
              (location.pathname === l.to ||
                l.children.some((c) => location.pathname === c.to));
            return l.children ? (
              <div
                className="nav-item has-sub"
                key={l.to}
                onMouseEnter={() => setOpenSub(l.to)}
                onMouseLeave={() => setOpenSub(null)}
              >
                <NavLink
                  to={l.to}
                  onClick={closeAll}
                  className={() => (isGroupActive ? "active" : "")}
                >
                  {l.label}
                </NavLink>
                <div className={`submenu ${openSub === l.to ? "open" : ""}`}>
                  {l.children.map((c) => (
                    <NavLink key={c.to} to={c.to} onClick={closeAll}>
                      {c.label}
                    </NavLink>
                  ))}
                </div>
              </div>
            ) : (
              <NavLink key={l.to} to={l.to} onClick={closeAll}>
                {l.label}
              </NavLink>
            );
          })}
          <Link to="/appointment" className="nav-cta" onClick={closeAll}>Book a Consult</Link>
        </nav>
      </div>
    </header>
  );
}
